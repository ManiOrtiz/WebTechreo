import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-techreo-card',
  templateUrl: './techreo-card.component.html',
  styleUrls: ['./techreo-card.component.scss'],
})
export class TechreoCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
