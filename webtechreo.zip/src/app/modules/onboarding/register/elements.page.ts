import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-elements',
  templateUrl: './elements.page.html',
  styleUrls: ['./elements.page.scss'],
})
export class ElementsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
